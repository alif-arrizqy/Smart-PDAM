"use strict";
$(function () {
    $("#datatable-1").DataTable({
        scrollCollapse: !0,
        scrollY: "50vh",
        scrollX: !0
    })
});