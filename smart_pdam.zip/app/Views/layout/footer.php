<div class="footer">
    <div class="footer-inner">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6 text-center text-sm-left mb-3 mb-sm-0">
                    <?= constant('FOOTER') ?>
                </div>
                <div class="col-sm-6 text-center text-sm-right">
                    <p class="mb-0"><i class="far fa-copyright"></i>
                        <span id="copyright-year"></span> All rights reserved
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>