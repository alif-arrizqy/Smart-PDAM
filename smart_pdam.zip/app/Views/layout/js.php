<script type="text/javascript" src="<?= base_url('public/assets/build/scripts/mandatory.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('public/assets/build/scripts/core.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('public/assets/build/scripts/vendor.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('public/assets/app/home.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('public/assets/widgets/general.js') ?>"></script>

<!-- Datatables -->
<script type="text/javascript" src="<?= base_url('public/assets/app/datatable/basic/scrollable.js') ?>"></script>
