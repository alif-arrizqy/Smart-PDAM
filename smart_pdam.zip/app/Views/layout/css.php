<script async="async" src="https://www.googletagmanager.com/gtag/js?id=G-XY1VQKQHG4"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'G-XY1VQKQHG4');
</script>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&amp;family=Roboto+Mono&amp;display=swap" rel="stylesheet">
<link href="<?= base_url('public/assets/build/styles/ltr-core.css') ?>" rel="stylesheet">
<link href="<?= base_url('public/assets/build/styles/ltr-vendor.css') ?>" rel="stylesheet">

<!-- Datatables -->
<link href="<? base_url('public/assets/app/datatable/datatables.net-bs/css/dataTables.bootstrap.min.css') ?>" rel="stylesheet">
<link href="<? base_url('public/assets/app/datatable/datatables.net-buttons-bs/css/buttons.bootstrap.min.css') ?>" rel="stylesheet">
<link href="<? base_url('public/assets/app/datatable/datatables.net-responsive-bs/css/responsive.bootstrap.min.css') ?>" rel="stylesheet">